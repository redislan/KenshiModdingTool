@echo off
rem Compile Kenshi Modding Tool en un seul .exe (dossier "dist")
where dotnet >nul 2>nul
if errorlevel 1 (
  echo Le SDK .NET n'est pas installe sur ce PC.
  echo Installe-le avec cette commande, puis relance build.bat :
  echo     winget install Microsoft.DotNet.SDK.8
  echo ou telecharge-le ici : https://aka.ms/dotnet/download
  pause
  exit /b 1
)
dotnet publish -c Release -o dist
if not exist "dist\KenshiModdingTool.exe" (
  echo.
  echo ECHEC de la compilation. Copie le message d'erreur ci-dessus.
  pause
  exit /b 1
)
echo.
echo OK : dist\KenshiModdingTool.exe
pause
